DIGITAL T-SHIRT DESIGN — Offline Adventure Dept

INCLUDED
- 1 transparent PNG
- 4500 x 5400 px
- 300 DPI metadata
- Digital product only; no physical item is included.

LICENSE
Personal use and small-business physical end-product use are allowed.
Do not resell, share, redistribute, upload, sublicense or give away the digital file itself.

PRINTING
Suitable for common DTF / DTG / heat-transfer workflows.
Always perform a test print. Printed colors may vary by garment, monitor, printer, ink and process.

AI DISCLOSURE
This original artwork was created with AI-assisted design direction and then prepared as a digital print file.
